#include <iostream>
#include <string>
using namespace std;

// Estructura que representa un proceso en el sistema
struct Proceso {
    int id; // id Identificador �nico del proceso (autoincremental)
    string nombre;// nombre Nombre descriptivo del proceso
    string estado;//estado Estado actual del proceso ("En espera", "En pila", etc.)
    int prioridad;//prioridad Nivel de prioridad (1-5, donde 1 es m�xima prioridad)
    Proceso* siguiente;//siguiente Puntero al siguiente proceso en la estructura de datos
};

//Implementa una lista enlazada simple para almacenar todos los procesos

class ListaProcesos {
private:
    Proceso* cabeza;     // Puntero al primer nodo de la lista
    int contadorId;      // Contador para generar IDs autoincrementales
    
public:
    // Constructor que inicializa una lista vac�a
    ListaProcesos() : cabeza(NULL), contadorId(1) {}

    void agregarProceso(string nombre, int prioridad) {
        Proceso* nuevo = new Proceso;//Agrega un nuevo proceso a la lista
        nuevo->id = contadorId++;
        nuevo->nombre = nombre;//nombre Nombre del proceso a crear
        nuevo->prioridad = prioridad;// prioridad Nivel de prioridad (1-5)
        nuevo->estado = "En espera";
        nuevo->siguiente = cabeza;//El proceso se agrega al principio de la lista
        cabeza = nuevo;
        cout << "Proceso creado con ID: " << nuevo->id << endl;
    }

     //Busca un proceso por su ID
    Proceso* buscarProceso(int id) {//id ID del proceso a buscar
        Proceso* actual = cabeza;//Puntero al proceso si existe, NULL si no se encuentra
        while (actual != NULL) {
            if (actual->id == id) return actual;
            actual = actual->siguiente;
        }
        return NULL;
    }

     //Muestra todos los procesos en la lista
    void mostrarProcesos() {
        Proceso* actual = cabeza;
        while (actual != NULL) {
            cout << "\nID: " << actual->id 
                 << "\nNombre: " << actual->nombre 
                 << "\nEstado: " << actual->estado
                 << "\nPrioridad: " << actual->prioridad << endl;
            actual = actual->siguiente;//Muestra ID, nombre, estado y prioridad de cada proceso
        }
    }
};

 //PilaProcesos
class PilaProcesos {//Implementa una pila (LIFO) para gesti�n de procesos
private:
    Proceso* tope;  // Puntero al elemento superior de la pila
    
public:

     //Constructor que inicializa una pila vac�a
    PilaProcesos() : tope(NULL) {}

     //Apila un proceso en el tope de la pila
    void apilar(Proceso* proceso) {// Puntero al proceso a apilar
        proceso->siguiente = tope;
        tope = proceso;
        proceso->estado = "En pila";
        cout << "Proceso " << proceso->id << " apilado.\n";//Cambia el estado del proceso a "En pila"
    }
    
     //Desapila el proceso del tope de la pila
    Proceso* desapilar() {
        if (tope == NULL) return NULL;
        Proceso* temp = tope;// Puntero al proceso desapilado, NULL si la pila est� vac�a
        tope = tope->siguiente;
        temp->estado = "Desapilado";//Cambia el estado del proceso a "Desapilado"
        return temp;
    }

     //Muestra los procesos en la pila
    void mostrarPila() {
        Proceso* actual = tope;
        while (actual != NULL) {
            cout << "ID: " << actual->id << " - " << actual->nombre << endl;
            actual = actual->siguiente;//Muestra desde el tope hasta el fondo de la pila
        }
    }
};

 //ColaProcesos
class ColaProcesos {//Implementa una cola (FIFO) para gesti�n de procesos
private:
    Proceso* frente;  // Puntero al primer elemento de la cola
    Proceso* final;   // Puntero al �ltimo elemento de la cola
    
public:
    
     //Constructor que inicializa una cola vac�a
    ColaProcesos() : frente(NULL), final(NULL) {}

     //Encola un proceso al final de la cola
    void encolar(Proceso* proceso) {//proceso Puntero al proceso a encolar
        proceso->siguiente = NULL;
        if (final == NULL) {
            frente = final = proceso;
        } else {
            final->siguiente = proceso;
            final = proceso;
        }
        proceso->estado = "En cola";
        cout << "Proceso " << proceso->id << " encolado.\n";//Cambia el estado del proceso a "En cola"
    }

     //Desencola el proceso del frente de la cola
    Proceso* desencolar() {
        if (frente == NULL) return NULL;//Puntero al proceso desencolado, NULL si la cola est� vac�a
        Proceso* temp = frente;
        frente = frente->siguiente;
        if (frente == NULL) final = NULL;
        temp->estado = "Desencolado";//Cambia el estado del proceso a "Desencolado"
        return temp;
    }

     //Muestra los procesos en la cola
    void mostrarCola() {
        Proceso* actual = frente;
        while (actual != NULL) {
            cout << "ID: " << actual->id << " - " << actual->nombre << endl;
            actual = actual->siguiente;//Muestra desde el frente hasta el final de la cola
        }
    }
};

 //Muestra el men� principal del sistema
void mostrarMenu() {
    cout << "\n=== GESTOR DE PROCESOS COMPLETO ===";
    cout << "\n1. Crear nuevo proceso";
    cout << "\n2. Listar todos los procesos";
    cout << "\n3. Apilar proceso";
    cout << "\n4. Desapilar proceso";
    cout << "\n5. Mostrar pila";
    cout << "\n6. Encolar proceso";
    cout << "\n7. Desencolar proceso";
    cout << "\n8. Mostrar cola";
    cout << "\n9. Cambiar estado de proceso";
    cout << "\n10. Salir";
    cout << "\nSeleccione opcion: ";
}

 //Funci�n principal del programa
int main() {
    ListaProcesos lista;  // Lista principal de procesos
    PilaProcesos pila;    // Pila LIFO
    ColaProcesos cola;    // Cola FIFO
    int opcion;           // Opci�n seleccionada por el usuario
    
    do {
        mostrarMenu();
        cin >> opcion;
        cin.ignore();  // Limpiar buffer de entrada
        
        switch(opcion) {
            case 1: {  // Crear nuevo proceso
                string nombre;
                int prioridad;
                cout << "Nombre del proceso: ";
                getline(cin, nombre);
                cout << "Prioridad (1-5): ";
                cin >> prioridad;
                lista.agregarProceso(nombre, prioridad);
                break;
            }
            case 2: {  // Listar todos los procesos
                cout << "\n=== LISTA DE PROCESOS ===";
                lista.mostrarProcesos();
                break;
            }
            case 3: {  // Apilar proceso
                int id;
                cout << "ID del proceso a apilar: ";
                cin >> id;
                Proceso* p = lista.buscarProceso(id);
                if (p != NULL) {
                    pila.apilar(p);
                } else {
                    cout << "Proceso no encontrado.\n";
                }
                break;
            }
            case 4: {  // Desapilar proceso
                Proceso* p = pila.desapilar();
                if (p != NULL) {
                    cout << "Proceso " << p->id << " desapilado.\n";
                } else {
                    cout << "Pila vacia.\n";
                }
                break;
            }
            case 5: {  // Mostrar pila
                cout << "\n=== CONTENIDO DE LA PILA ===";
                pila.mostrarPila();
                break;
            }
            case 6: {  // Encolar proceso
                int id;
                cout << "ID del proceso a encolar: ";
                cin >> id;
                Proceso* p = lista.buscarProceso(id);
                if (p != NULL) {
                    cola.encolar(p);
                } else {
                    cout << "Proceso no encontrado.\n";
                }
                break;
            }
            case 7: {  // Desencolar proceso
                Proceso* p = cola.desencolar();
                if (p != NULL) {
                    cout << "Proceso " << p->id << " desencolado.\n";
                } else {
                    cout << "Cola vacia.\n";
                }
                break;
            }
            case 8: {  // Mostrar cola
                cout << "\n=== CONTENIDO DE LA COLA ===";
                cola.mostrarCola();
                break;
            }
            case 9: {  // Cambiar estado de proceso
                int id;
                string nuevoEstado;
                cout << "ID del proceso a actualizar: ";
                cin >> id;
                Proceso* p = lista.buscarProceso(id);
                if (p != NULL) {
                    cout << "Nuevo estado: ";
                    cin.ignore();
                    getline(cin, nuevoEstado);
                    p->estado = nuevoEstado;
                    cout << "Estado actualizado.\n";
                } else {
                    cout << "Proceso no encontrado.\n";
                }
                break;
            }
            case 10:  // Salir del sistema
                cout << "Saliendo del sistema...\n";
                break;
            default:
                cout << "Opcion no valida.\n";
        }
    } while (opcion != 10);
    
    return 0;//C�digo de salida del programa
}

